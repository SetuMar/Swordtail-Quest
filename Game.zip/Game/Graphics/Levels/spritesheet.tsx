<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="spritesheet" tilewidth="64" tileheight="64" tilecount="6084" columns="78">
 <image source="../spritesheet.png" width="5000" height="5000"/>
</tileset>
